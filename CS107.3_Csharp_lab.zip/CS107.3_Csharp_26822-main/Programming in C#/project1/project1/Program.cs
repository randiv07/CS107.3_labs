﻿using System;

namespace TextApplication
{
    class MainClass
    {
        Static void Main(string[] args)
        {
            string name; // Declaring a string variable to store the value

            Consloe.WriteLine("Enter your name:");
            name = Console.ReadLine(); // Taking user input to the value

            Console.WriteLine("Welcome " = name); // Displaying the variable

            Console.ReadLine(); // Avoid closing the console
        }
    }
}

