﻿namespace TextApplication
{
    internal class Staticvoid
    {
    }
}