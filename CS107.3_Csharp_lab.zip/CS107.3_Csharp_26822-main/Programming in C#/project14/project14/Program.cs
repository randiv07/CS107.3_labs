﻿namespace project14;
class Program
{
    static void Main(string[] args)
    {
        int rad;
        Console.WriteLine("Enter the radius:");
        rad = int.Parse(Console.ReadLine());

        calculate Objsihan = new calculate();
        Objsihan.circle(rad);
        Console.ReadLine();
    }
}

