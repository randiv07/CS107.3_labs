﻿using System;
namespace project
{
	internal class student
	{
		public int sum;

		private void MyMethod()
		{
			sum = 10;
		}
	}
}

