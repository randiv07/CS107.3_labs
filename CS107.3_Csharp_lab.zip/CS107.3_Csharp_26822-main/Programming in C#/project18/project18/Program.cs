﻿namespace project18;
class Program
{
    static void Main(string[] args)
    {
        person name = new person();
        Console.WriteLine(name.a+"");
    }
}

