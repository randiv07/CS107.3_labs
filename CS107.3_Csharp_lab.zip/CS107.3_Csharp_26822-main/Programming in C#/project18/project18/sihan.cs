﻿using System;
namespace project18
{
	public class sihan
	{
		public  sihan() //constuctors
		{
			Console.WriteLine("Hello world");
		}

	}
}

