﻿using System;
namespace project18
{
	public class person
	{
		int a,b;
		public person()
		{
			a = 200;
			b = 400;
		}
	}
}

