﻿using System;
namespace project11
{
	public class summation
	{
		public void sum(int a ,int b)
		{
			Console.WriteLine($"The sum is:{a + b}");
		}
	}
}

