﻿using System;
using classes2;

namespace classes2
{
	public class Name
	{
		public void sihan(string a)
		{
			Console.WriteLine($"Your name is {a}");
		}
	}
}

 