﻿namespace project5;
class Program
{
    static void Main(string[] args)
    {
        string a;
        Console.WriteLine("Enter your name");
        a = Console.ReadLine();
        name Objsihan = new name();
        Objsihan.sithu(a);
        Console.ReadLine();

    }
}

