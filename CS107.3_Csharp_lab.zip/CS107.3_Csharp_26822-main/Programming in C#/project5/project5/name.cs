﻿using System;
namespace project5
{
	public class name
	{
		public void sithu(string nam)
		{
			Console.WriteLine($"Your name is {nam}");
		}
	}
}

