﻿namespace private1;
class Program
{
    class car
    {
        private void mode()
        {
            Console.WriteLine("Hello world");
        }
        static void Main(string[] args)
        {
            car Objmod = new car();
            Objmod.mode();
        }
    }

}

