﻿using System;
namespace project8
{
	public class sum
	{
		public void addition(int a, int b)
		{
			int sum;
			sum = a + b;
			Console.WriteLine($"The sum is:{sum}");
		}
	}
}

