﻿using System;
namespace project16
{
	public class array
	{
		public array()
		{
		}
	}
}

