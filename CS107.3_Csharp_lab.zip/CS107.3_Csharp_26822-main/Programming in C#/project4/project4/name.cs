﻿using System;
namespace project4
{
	public class name
	{
		private int age;
		private string nam;

		public void info(string nam, int age)
		{
			nam = nam;
			age = age;
			Console.WriteLine($"Your name is {nam}");
			Console.WriteLine($"Your age is {age}");
		}
	}
}

