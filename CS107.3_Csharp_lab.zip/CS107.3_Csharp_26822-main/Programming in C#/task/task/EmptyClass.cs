﻿using System;
namespace task
{
	public class EmptyClass
	{
		public void ()
		{
            

        }
	}
}

