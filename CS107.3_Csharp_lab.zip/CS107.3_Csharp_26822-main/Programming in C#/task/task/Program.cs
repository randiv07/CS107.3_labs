﻿namespace task;
class Program
{
    static void Main(string[] args)
    {
        student objStd = new student();
        objStd.MyInfo();
        Console.ReadLine();
    }
}

