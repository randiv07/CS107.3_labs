﻿int a,i;
Console.WriteLine("Enter an Integer:");
a = int.Parse(Console.ReadLine());

for(i=a+1;i<=a+20;i++)
{
    Console.WriteLine(""+i);
}