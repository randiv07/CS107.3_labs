﻿using System;
using System.Threading.Tasks;
using System.Linq;
using System.Collections.Generic;
namespace project10
{
    class Program
    {
        public static void Main(string[] args)
        {
            Program ob = new Program();
            ob.fun();
        }
        void fun()
        {
            Console.Write("hello");
            Console.ReadKey();
        }
    }
}

