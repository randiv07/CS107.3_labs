﻿using System;
namespace project10
{
	public class classes
	{
		public classes()
		{
		}
	}
}

