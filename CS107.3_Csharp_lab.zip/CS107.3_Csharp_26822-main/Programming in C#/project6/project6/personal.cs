﻿using System;
namespace project6
{
	public class personal
	{
		public void info(string name,double batch )
		{
			Console.WriteLine($"Your name is {name} and you are from {batch} batch");
		}
	}
}