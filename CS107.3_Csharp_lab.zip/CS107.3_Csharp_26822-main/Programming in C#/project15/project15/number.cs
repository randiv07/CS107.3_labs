﻿using System;
namespace project15
{
	public class number
	{
		public void evenodd(int number)
		{
			if (number % 2 == 0)
				Console.WriteLine("even");
			else
				Console.WriteLine("odd");
		}
	}
}

