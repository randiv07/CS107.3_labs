﻿myinfo ObjStudent = new myinfo();
ObjStudent.myinfo();